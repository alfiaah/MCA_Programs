package com.example.actionbar1;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu); // Use the same main_menu.xml as before
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();

        if (itemId == R.id.action_edit) {
            Toast.makeText(this, "Edit action clicked", Toast.LENGTH_SHORT).show();
            // Implement edit action logic
            return true;
        } else if (itemId == R.id.action_delete) {
            Toast.makeText(this, "Delete action clicked", Toast.LENGTH_SHORT).show();
            // Implement delete action logic
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
