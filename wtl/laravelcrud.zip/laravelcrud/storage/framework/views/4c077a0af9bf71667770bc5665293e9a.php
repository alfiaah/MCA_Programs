<?php if(session('status')): ?>
<div class="alert alert-sucess"><?php echo e(session('status')); ?></div>
    
<?php endif; ?>
<h1>Hello Category</h1><?php /**PATH C:\xampp\htdocs\laravelcrud\resources\views/category/index.blade.php ENDPATH**/ ?>