<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>category</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
  <body>
   
    <div class="container m-5">
      <h1>category</h1>
      <form action="<?php echo e(url('/create')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <?php if(session('status')): ?>
            <div class="alert alert-danger"><?php echo e(session('status')); ?></div>
            <?php endif; ?>
            <label>name:</label>
            <input type="text" class="form-control" value="<?php echo e(old('name')); ?>" name="name" id="name">    
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>      
        </div>
        
        <div class="mb-3">
            <label>description:</label>
            <textarea class="form-control" name="description" rows="3" value="<?php echo e(old('description')); ?>">
            </textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>        
         </div>
        
        <button type="submit" class="btn btn-primary">Submit</button>
      </form>
    </div>
  </body>
</html><?php /**PATH C:\xampp\htdocs\laravelcrud\resources\views/category/create.blade.php ENDPATH**/ ?>