<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    public function registerview(){
        return view('register');
    }
    public function register(Request $request){
        $request->validate([
            'name'=>'required','min:5',
            'password'=>'required','min:5',
            'email'=>'required',
        ]);

        User::create([
            'email'=>$request->email,
            'name'=>$request->name,
            'password'=>$request->password,   
        ]);
        return redirect('/login')->with('status','registartion sucessfull');
    }
    public function loginview(){
        return view('/login');
    }
    public function login(){
        
    }

}
