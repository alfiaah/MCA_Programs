<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;

Route::get('/', function () {
    return view('welcome');
});
Route::get('/register',[LoginController::class,'registerview'] );
Route::post('/register',[LoginController::class,'register'] );

Route::get('/login',[LoginController::class,'loginview'] );
Route::post('/login',[LoginController::class,'login'] );